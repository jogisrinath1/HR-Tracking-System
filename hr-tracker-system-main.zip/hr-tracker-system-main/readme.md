# HR Recruitment and Applicant Tracking System

A platform for HR professional's to manage job postings, applications and candidate evaluations

## Data Modeling:

![alt text](https://github.com/chandu-cpz/hr-tracker-system/blob/main/docs/images/Data_Model.png?raw=true)
