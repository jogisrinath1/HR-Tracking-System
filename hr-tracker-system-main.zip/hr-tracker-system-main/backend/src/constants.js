export const DB_NAME = "hrdb";
